# UptrainoAI — AI Sales Practice Platform (Frontend)

This is a Vite + React + TypeScript frontend scaffold for UptrainoAI with Tailwind CSS, Shadcn-like UI primitives, Lucide icons, and Wouter routing.

Features
- Routes for landing, login, register, dashboard, practice, history, referral, leaderboard, payment, tips, community, settings, support, feedback
- Global UI primitives: Navbar, Sidebar, ThemeToggle, GlassCard, StatCard, Table, Modal, Buttons, Input/Form components
- Tailwind config with specified colors and fonts
- Netlify-ready build settings

Local development
1. Install
   npm install

2. Run dev server
   npm run dev

Build for production
  npm run build

Deploy to Netlify
- Build command: npm run build
- Publish directory: dist

Netlify steps:
1. Connect your GitHub repository to Netlify.
2. Set Build Command to `npm run build`.
3. Set Publish directory to `dist`.
4. Add environment variables if needed.
5. Deploy.

Fonts
- Inter (body), Sora (headings), JetBrains Mono (mono) are loaded from Google Fonts in index.html.

Project layout:
- src/
  - assets/
  - components/
  - hooks/
  - lib/
  - pages/
  - styles/

Start hacking!