/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx,js,jsx,html}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
        heading: ['Sora', 'ui-serif', 'system-ui'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular']
      },
      colors: {
        background: '#f8fafc',
        foreground: '#0f172a',
        primary: {
          DEFAULT: '#06b6d4'
        },
        muted: '#e2e8f0'
      },
      boxShadow: {
        glass: '0 8px 30px rgba(15,23,42,0.12)'
      },
      backdropBlur: {
        xl: '20px'
      }
    }
  },
  plugins: [require('@tailwindcss/forms')]
}