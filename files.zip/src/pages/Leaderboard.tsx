import React from 'react'
import GlassCard from '../components/ui/GlassCard'

const Leaderboard: React.FC = () => {
  return (
    <div>
      <h1 className="h2 mb-4">Leaderboard</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {[
          { name: 'Aisha', points: 1240 },
          { name: 'Rohan', points: 1120 },
          { name: 'Nina', points: 980 }
        ].map((p, i) => (
          <GlassCard key={i}>
            <div className="font-semibold">{p.name}</div>
            <div className="text-sm text-muted">{p.points} pts</div>
          </GlassCard>
        ))}
      </div>
    </div>
  )
}

export default Leaderboard