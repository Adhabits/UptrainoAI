import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'

const Settings: React.FC = () => {
  return (
    <div className="max-w-xl">
      <h1 className="h2 mb-4">Settings</h1>
      <GlassCard>
        <div className="space-y-3">
          <Input label="Name" />
          <Input label="Email" />
          <div className="flex justify-end">
            <Button>Save</Button>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}

export default Settings