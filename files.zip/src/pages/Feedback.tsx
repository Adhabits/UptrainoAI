import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

const Feedback: React.FC = () => {
  return (
    <div className="max-w-xl">
      <h1 className="h2 mb-4">Feedback</h1>
      <GlassCard>
        <form onSubmit={(e) => { e.preventDefault(); alert('Thanks for feedback (mock)') }} className="space-y-3">
          <Input label="What did you like?" />
          <Input label="What can we improve?" />
          <div className="flex justify-end">
            <Button>Send feedback</Button>
          </div>
        </form>
      </GlassCard>
    </div>
  )
}

export default Feedback