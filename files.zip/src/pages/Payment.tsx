import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

const Payment: React.FC = () => {
  const handlePay = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Payment processed (mock)')
  }

  return (
    <div className="max-w-md">
      <h1 className="h2 mb-4">Payment</h1>
      <GlassCard>
        <form onSubmit={handlePay} className="space-y-3">
          <Input label="Card number" name="card" />
          <div className="flex gap-2">
            <Input label="MM/YY" name="expiry" />
            <Input label="CVC" name="cvc" />
          </div>
          <div className="flex justify-end">
            <Button>Pay ₹999</Button>
          </div>
        </form>
      </GlassCard>
    </div>
  )
}

export default Payment