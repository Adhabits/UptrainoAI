import React, { useEffect, useState } from 'react'
import StatCard from '../components/ui/StatCard'
import { fetchStats } from '../lib/api'
import { Trophy, Clock } from 'lucide-react'
import GlassCard from '../components/ui/GlassCard'
import { Link } from 'wouter'

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<{ sessions: number; avgScore: number; streak: number } | null>(null)

  useEffect(() => {
    fetchStats().then(setStats)
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <StatCard title="Sessions" value={stats?.sessions ?? '—'} delta="+12%" icon={<Clock />} />
        <StatCard title="Avg Score" value={stats?.avgScore ?? '—'} delta="+4%" icon={<Trophy />} />
        <StatCard title="Streak" value={stats?.streak ?? '—'} delta="+1" icon={<Trophy />} />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <GlassCard>
          <h3 className="font-semibold mb-2">Recent activity</h3>
          <p className="text-sm">Your last sessions and performance trends appear here.</p>
          <div className="mt-4">
            <Link href="/history"><a className="text-sm text-primary">View history →</a></Link>
          </div>
        </GlassCard>

        <GlassCard>
          <h3 className="font-semibold mb-2">Quick actions</h3>
          <div className="flex gap-2">
            <Link href="/practice"><a><button className="btn-primary">Start practice</button></a></Link>
            <Link href="/leaderboard"><a><button className="btn-secondary">See leaderboard</button></a></Link>
          </div>
        </GlassCard>
      </div>
    </div>
  )
}

export default Dashboard