import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Button from '../components/ui/Button'

const Referral: React.FC = () => {
  return (
    <div className="max-w-xl">
      <h1 className="h2 mb-4">Referral</h1>
      <GlassCard>
        <div className="mb-3">
          <div className="text-sm text-muted">Share this link to invite teammates</div>
          <div className="mt-2 code-mono bg-white/10 p-2 rounded">https://uptraino.ai/ref/XYZ123</div>
        </div>
        <div className="flex gap-2">
          <Button>Copy link</Button>
          <Button variant="secondary">Share</Button>
        </div>
      </GlassCard>
    </div>
  )
}

export default Referral