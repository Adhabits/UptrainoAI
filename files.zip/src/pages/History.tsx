import React, { useEffect, useState } from 'react'
import { fetchHistory } from '../lib/api'
import Table from '../components/ui/Table'

type Row = { id: string; date: string; duration: string; score: number; note: string }

const History: React.FC = () => {
  const [data, setData] = useState<Row[]>([])

  useEffect(() => {
    fetchHistory().then((h) => setData(h as Row[]))
  }, [])

  const columns = [
    { header: 'Date', accessor: (r: Row) => r.date },
    { header: 'Duration', accessor: (r: Row) => r.duration },
    { header: 'Score', accessor: (r: Row) => <span className="code-mono">{r.score}</span> },
    { header: 'Note', accessor: (r: Row) => r.note }
  ]

  return (
    <div>
      <h1 className="h2 mb-4">Call history</h1>
      <div className="p-4 glass rounded-lg">
        <Table data={data} columns={columns} />
      </div>
    </div>
  )
}

export default History