import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Button from '../components/ui/Button'

const Community: React.FC = () => {
  return (
    <div>
      <h1 className="h2 mb-4">Community</h1>
      <GlassCard>
        <div className="mb-3">Join channels to practice with peers and share tips.</div>
        <div className="flex gap-2">
          <Button>Join Slack</Button>
          <Button variant="secondary">Join Discord</Button>
        </div>
      </GlassCard>
    </div>
  )
}

export default Community