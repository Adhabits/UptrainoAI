import React from 'react'
import { Link } from 'wouter'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import { Form } from '../components/ui/Form'

const Login: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Logged in (mock)')
  }

  return (
    <div className="max-w-md mx-auto">
      <h1 className="h2 mb-4">Sign in</h1>
      <div className="p-6 glass rounded-lg">
        <Form onSubmit={handleSubmit}>
          <Input label="Email" type="email" required />
          <Input label="Password" type="password" required />
          <div className="flex items-center justify-between">
            <Button>Sign in</Button>
            <Link href="/register"><a className="text-sm">Create account</a></Link>
          </div>
        </Form>
      </div>
    </div>
  )
}

export default Login