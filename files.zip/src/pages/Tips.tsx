import React from 'react'
import GlassCard from '../components/ui/GlassCard'

const Tips: React.FC = () => {
  return (
    <div>
      <h1 className="h2 mb-4">Tips</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {[
          { title: 'Opening lines', text: 'Start with a clear value proposition.' },
          { title: 'Handling objections', text: 'Acknowledge and pivot to benefit.' },
          { title: 'Closing', text: 'Ask for the next step with confidence.' }
        ].map((t, i) => (
          <GlassCard key={i}>
            <div className="font-semibold">{t.title}</div>
            <div className="text-sm mt-2">{t.text}</div>
          </GlassCard>
        ))}
      </div>
    </div>
  )
}

export default Tips