import React from 'react'
import Input from '../components/ui/Input'
import Button from '../components/ui/Button'
import { Form } from '../components/ui/Form'

const Register: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('Registered (mock)')
  }

  return (
    <div className="max-w-md mx-auto">
      <h1 className="h2 mb-4">Create account</h1>
      <div className="p-6 glass rounded-lg">
        <Form onSubmit={handleSubmit}>
          <Input label="Full name" name="name" required />
          <Input label="Email" type="email" name="email" required />
          <Input label="Password" type="password" name="password" required />
          <div className="flex justify-end">
            <Button>Register</Button>
          </div>
        </Form>
      </div>
    </div>
  )
}

export default Register