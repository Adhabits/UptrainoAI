import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'

const Support: React.FC = () => {
  return (
    <div className="max-w-xl">
      <h1 className="h2 mb-4">Support</h1>
      <GlassCard>
        <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); alert('Support request sent (mock)') }}>
          <Input label="Subject" />
          <Input label="Email" />
          <div>
            <label className="text-sm mb-1 block">Message</label>
            <textarea className="w-full p-2 rounded-md border border-muted/60" rows={5}></textarea>
          </div>
          <div className="flex justify-end">
            <Button>Send</Button>
          </div>
        </form>
      </GlassCard>
    </div>
  )
}

export default Support