import React from 'react'
import { Link } from 'wouter'
import GlassCard from '../components/ui/GlassCard'
import { trainers } from '../lib/data'
import { Phone } from 'lucide-react'
import Button from '../components/ui/Button'

const Landing: React.FC = () => {
  return (
    <div className="space-y-12">
      {/* Hero */}
      <section className="rounded-xl overflow-hidden relative py-24 px-6 bg-gradient-to-r from-primary/60 to-white/10">
        <div className="max-w-[1200px] mx-auto flex items-center gap-10">
          <div className="flex-1">
            <h1 className="h1 text-4xl mb-4">Practice sales calls with AI. Improve faster.</h1>
            <p className="text-lg mb-6 max-w-xl">UptrainoAI helps reps sharpen pitch, handle objections, and close more deals through realistic AI practice sessions and measurable feedback.</p>
            <div className="flex gap-3">
              <Link href="/register"><a><Button>Get Started</Button></a></Link>
              <Link href="/pricing"><a><Button variant="secondary">See Pricing</Button></a></Link>
            </div>
            <div className="mt-6 flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-3 rounded-full glass"><Phone size={18} /></div>
                <div>
                  <div className="text-sm">Practice on mobile</div>
                  <div className="text-xs text-muted">On-the-go coaching</div>
                </div>
              </div>
            </div>
          </div>
          <div className="w-[280px] hidden md:block">
            <img src="/src/assets/phone-mockup.svg" alt="phone mockup" />
          </div>
        </div>
      </section>

      {/* Pain Points */}
      <section className="grid md:grid-cols-3 gap-6">
        <GlassCard>
          <h3 className="h2 mb-2">Nervous on calls?</h3>
          <p>Practice real scenarios until your delivery is confident and consistent.</p>
        </GlassCard>
        <GlassCard>
          <h3 className="h2 mb-2">Low conversion?</h3>
          <p>Target improvement areas with actionable AI feedback.</p>
        </GlassCard>
        <GlassCard>
          <h3 className="h2 mb-2">Onboarding slow?</h3>
          <p>Ramp reps faster with guided training paths and role-play sessions.</p>
        </GlassCard>
      </section>

      {/* How it works */}
      <section>
        <h2 className="h2 mb-6">How it works</h2>
        <div className="grid md:grid-cols-4 gap-4">
          {['Choose scenario','Start practice','Get AI feedback','Improve & repeat'].map((s, i) => (
            <div key={i} className="p-4 bg-white/60 dark:bg-black/20 rounded-lg glass">
              <div className="text-primary font-bold mb-2">Step {i+1}</div>
              <div className="text-sm">{s}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Trainers */}
      <section>
        <h2 className="h2 mb-6">Trainers</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {trainers.map((t) => (
            <div key={t.id} className="p-4 rounded-lg glass flex items-center gap-4">
              <img src={t.avatar} alt={t.name} className="w-16 h-16 rounded-full" />
              <div>
                <div className="font-semibold">{t.name}</div>
                <div className="text-sm text-muted">{t.bio}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section>
        <h2 className="h2 mb-6">Features</h2>
        <div className="grid md:grid-cols-4 gap-4">
          {[
            'Realistic AI scenarios',
            'Score & feedback',
            'Custom scenarios',
            'Progress tracking',
            'Leaderboards',
            'Mobile app',
            'Team analytics',
            'Secure and private'
          ].map((f, i) => (
            <div key={i} className="p-4 bg-white/60 rounded-lg glass">
              <div className="font-semibold">{f}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-md">
        <h2 className="h2 mb-4">Pricing</h2>
        <div className="p-6 rounded-xl glass">
          <div className="text-xs text-muted">One-time / Monthly</div>
          <div className="flex items-baseline gap-2">
            <div className="text-3xl font-bold code-mono">₹999</div>
            <div className="text-sm text-muted">per month</div>
          </div>
          <p className="mt-3 text-sm">Unlimited practice sessions, leaderboards, and analytics.</p>
          <div className="mt-4">
            <Button>Buy Now</Button>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section>
        <h2 className="h2 mb-6">Testimonials</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {['"Cut call time by 25%"','"Team ramped faster"','"Loved the AI feedback"'].map((t,i)=>(
            <div key={i} className="p-4 glass rounded-lg">
              <div className="font-semibold mb-2">User {i+1}</div>
              <div className="text-sm">{t}</div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section>
        <h2 className="h2 mb-4">FAQ</h2>
        <div className="space-y-2">
          <details className="p-4 bg-white/50 glass rounded-md">
            <summary className="font-semibold">What is UptrainoAI?</summary>
            <div className="mt-2 text-sm">An AI-powered practice platform to improve sales calls.</div>
          </details>
          <details className="p-4 bg-white/50 glass rounded-md">
            <summary className="font-semibold">How long are sessions?</summary>
            <div className="mt-2 text-sm">Most practice sessions are 5–20 minutes.</div>
          </details>
          <details className="p-4 bg-white/50 glass rounded-md">
            <summary className="font-semibold">Is there a free trial?</summary>
            <div className="mt-2 text-sm">Yes — 7-day trial available.</div>
          </details>
        </div>
      </section>

      {/* Footer */}
      <footer className="pt-12 pb-6 border-t border-muted/40">
        <div className="flex items-center justify-between">
          <div>
            <img src="/src/assets/logo.svg" alt="logo" className="w-10 h-10" />
            <div className="text-sm text-muted mt-2">© UptrainoAI 2025</div>
          </div>
          <div className="text-sm">
            <Link href="/support"><a className="mr-4">Support</a></Link>
            <Link href="/privacy"><a>Privacy</a></Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default Landing