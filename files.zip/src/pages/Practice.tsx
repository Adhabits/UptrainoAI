import React from 'react'
import GlassCard from '../components/ui/GlassCard'
import Button from '../components/ui/Button'

const Practice: React.FC = () => {
  const startPractice = () => {
    alert('Starting AI practice session (mock)')
  }

  return (
    <div>
      <h1 className="h2 mb-4">Practice</h1>
      <GlassCard>
        <div className="flex items-center justify-between">
          <div>
            <div className="font-semibold">Choose a scenario</div>
            <div className="text-sm text-muted">Cold outreach • Discovery • Demo</div>
          </div>
          <div>
            <Button onClick={startPractice}>Start practice</Button>
          </div>
        </div>
      </GlassCard>

      <div className="mt-6 grid md:grid-cols-3 gap-4">
        {['Cold call', 'Discovery', 'Demo'].map((s) => (
          <div key={s} className="p-4 rounded-lg glass">
            <div className="font-semibold">{s}</div>
            <div className="text-sm mt-2">Simulate a {s.toLowerCase()} with AI responses and scoring.</div>
            <div className="mt-4">
              <Button>Choose</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Practice