// Mock API layer - replace with real endpoints
export async function fetchStats() {
  return Promise.resolve({
    sessions: 124,
    avgScore: 78,
    streak: 5
  })
}

export async function fetchHistory() {
  return Promise.resolve([
    { id: '1', date: '2025-11-20', duration: '12m', score: 82, note: 'Cold outreach practice' },
    { id: '2', date: '2025-11-18', duration: '9m', score: 74, note: 'Discovery call' },
    { id: '3', date: '2025-11-16', duration: '14m', score: 91, note: 'Demo simulation' }
  ])
}