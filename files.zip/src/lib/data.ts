export const trainers = [
  {
    id: 'riya',
    name: 'Riya Sharma',
    bio: 'Customer success + negotiation expert',
    avatar: '/src/assets/avatars/riya.svg'
  },
  {
    id: 'aarav',
    name: 'Aarav Patel',
    bio: 'Enterprise sales coach',
    avatar: '/src/assets/avatars/aarav.svg'
  },
  {
    id: 'max',
    name: 'Max Carter',
    bio: 'SaaS demo specialist',
    avatar: '/src/assets/avatars/max.svg'
  }
]

export const faqs = [
  { q: 'What is UptrainoAI?', a: 'An AI-powered practice platform to improve sales calls.' },
  { q: 'How long are sessions?', a: 'Most practice sessions are 5–20 minutes.' },
  { q: 'Is there a free trial?', a: 'Yes — 7-day trial available.' }
]