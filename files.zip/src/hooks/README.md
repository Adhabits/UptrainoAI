Helper hooks:
- useLocalStorage
- useModal