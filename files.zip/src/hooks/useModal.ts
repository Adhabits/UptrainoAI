import { useState } from 'react'

export function useModal() {
  const [open, setOpen] = useState(false)
  return {
    open,
    openModal: () => setOpen(true),
    closeModal: () => setOpen(false),
    toggle: () => setOpen((s) => !s)
  }
}