import React from 'react'

type Column<T> = {
  header: string
  accessor: (row: T) => React.ReactNode
}

type Props<T> = {
  data: T[]
  columns: Column<T>[]
}

export function Table<T>({ data, columns }: Props<T>) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white/60 dark:bg-black/20 rounded-md">
        <thead>
          <tr>
            {columns.map((col, idx) => (
              <th key={idx} className="text-left px-4 py-2 text-sm border-b border-muted/40">{col.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rIdx) => (
            <tr key={rIdx} className="odd:bg-white/40 even:bg-white/20">
              {columns.map((col, cIdx) => (
                <td key={cIdx} className="px-4 py-3 text-sm border-b border-muted/20">{col.accessor(row)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default Table