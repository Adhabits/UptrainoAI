import React from 'react'
import clsx from 'clsx'

type Props = {
  children: React.ReactNode
  className?: string
}

const GlassCard: React.FC<Props> = ({ children, className }) => {
  return (
    <div className={clsx('glass rounded-xl p-6', className)}>{children}</div>
  )
}

export default GlassCard