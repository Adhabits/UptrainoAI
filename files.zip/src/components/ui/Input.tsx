import React from 'react'
import clsx from 'clsx'

type InputProps = React.InputHTMLAttributes<HTMLInputElement> & {
  label?: string
  error?: string
}

const Input: React.FC<InputProps> = ({ label, error, className, ...props }) => {
  return (
    <div className="flex flex-col">
      {label && <label className="text-sm mb-1">{label}</label>}
      <input
        className={clsx(
          'px-3 py-2 rounded-md border border-muted/60 bg-white/60 dark:bg-black/20',
          className
        )}
        {...props}
      />
      {error && <span className="text-xs text-red-600 mt-1">{error}</span>}
    </div>
  )
}

export default Input