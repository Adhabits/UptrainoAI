import React, { useEffect, useState } from 'react'
import { Sun, Moon } from 'lucide-react'

const ThemeToggle: React.FC = () => {
  const [dark, setDark] = useState<boolean>(() => {
    try {
      const ls = localStorage.getItem('theme')
      if (ls) return ls === 'dark'
    } catch {
      // ignore
    }
    return false
  })

  useEffect(() => {
    const root = document.documentElement
    if (dark) {
      root.classList.add('dark')
      localStorage.setItem('theme', 'dark')
    } else {
      root.classList.remove('dark')
      localStorage.setItem('theme', 'light')
    }
  }, [dark])

  return (
    <button
      aria-label="Toggle theme"
      onClick={() => setDark((s) => !s)}
      className="p-2 rounded-md border border-muted/30"
    >
      {dark ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  )
}

export default ThemeToggle