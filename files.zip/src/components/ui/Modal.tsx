import React from 'react'
import clsx from 'clsx'

type Props = {
  open: boolean
  title?: string
  onClose: () => void
  children: React.ReactNode
}

const Modal: React.FC<Props> = ({ open, title, onClose, children }) => {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={clsx('relative z-10 w-full max-w-lg p-6 rounded-lg glass')}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">{title}</h3>
          <button onClick={onClose} className="text-muted">Close</button>
        </div>
        <div>{children}</div>
      </div>
    </div>
  )
}

export default Modal