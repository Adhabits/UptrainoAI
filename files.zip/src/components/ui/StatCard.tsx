import React from 'react'

type Props = {
  title: string
  value: string | number
  delta?: string
  icon?: React.ReactNode
}

const StatCard: React.FC<Props> = ({ title, value, delta, icon }) => {
  return (
    <div className="bg-white/60 dark:bg-black/30 glass p-4 rounded-lg flex items-center justify-between">
      <div>
        <div className="text-xs text-muted uppercase">{title}</div>
        <div className="text-2xl font-bold code-mono">{value}</div>
        {delta && <div className="text-sm text-green-600 mt-1">{delta}</div>}
      </div>
      <div className="text-primary">{icon}</div>
    </div>
  )
}

export default StatCard