import React from 'react'
import { Link } from 'wouter'
import { Home, Play, Clock, Users, Award, CreditCard, Settings, LifeBuoy, MessageCircle, Gift } from 'lucide-react'

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: Home },
  { href: '/practice', label: 'Practice', icon: Play },
  { href: '/history', label: 'History', icon: Clock },
  { href: '/referral', label: 'Referral', icon: Gift },
  { href: '/leaderboard', label: 'Leaderboard', icon: Award },
  { href: '/payment', label: 'Payment', icon: CreditCard },
  { href: '/community', label: 'Community', icon: Users },
  { href: '/tips', label: 'Tips', icon: MessageCircle },
  { href: '/support', label: 'Support', icon: LifeBuoy },
  { href: '/settings', label: 'Settings', icon: Settings }
]

const Sidebar: React.FC = () => {
  return (
    <aside className="w-64 hidden lg:block border-r border-muted/40 min-h-[calc(100vh-64px)] p-4">
      <div className="flex flex-col gap-2">
        {navItems.map((item) => {
          const Icon = item.icon
          return (
            <Link href={item.href} key={item.href}>
              <a className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-primary/10">
                <Icon size={18} />
                <span className="text-sm">{item.label}</span>
              </a>
            </Link>
          )
        })}
      </div>
    </aside>
  )
}

export default Sidebar