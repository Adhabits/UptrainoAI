import React from 'react'
import { Link } from 'wouter'
import ThemeToggle from '../ui/ThemeToggle'
import { User, Menu } from 'lucide-react'

const Navbar: React.FC = () => {
  return (
    <header className="w-full border-b border-muted/40 bg-white/60 dark:bg-black/40 glass">
      <div className="max-w-[1200px] mx-auto flex items-center justify-between p-4">
        <div className="flex items-center space-x-4">
          <Link href="/"><a className="text-lg font-heading text-primary">UptrainoAI</a></Link>
          <nav className="hidden md:flex gap-4 items-center text-sm">
            <Link href="/practice"><a className="hover:underline">Practice</a></Link>
            <Link href="/dashboard"><a className="hover:underline">Dashboard</a></Link>
            <Link href="/leaderboard"><a className="hover:underline">Leaderboard</a></Link>
            <Link href="/tips"><a className="hover:underline">Tips</a></Link>
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link href="/login"><a className="px-3 py-1 rounded-md border border-muted">Sign in</a></Link>
          <button className="md:hidden p-2 rounded-md"><Menu size={18} /></button>
        </div>
      </div>
    </header>
  )
}

export default Navbar