import React from 'react'
import Navbar from '../nav/Navbar'
import Sidebar from '../nav/Sidebar'

type Props = {
  children: React.ReactNode
}

export const AppShell: React.FC<Props> = ({ children }) => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6 max-w-[1200px] mx-auto">{children}</main>
      </div>
    </div>
  )
}

export default AppShell