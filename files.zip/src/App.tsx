import React from 'react'
import { Route } from 'wouter'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Practice from './pages/Practice'
import History from './pages/History'
import Referral from './pages/Referral'
import Leaderboard from './pages/Leaderboard'
import Payment from './pages/Payment'
import Tips from './pages/Tips'
import Community from './pages/Community'
import Settings from './pages/Settings'
import Support from './pages/Support'
import Feedback from './pages/Feedback'
import { AppShell } from './components/layout/AppShell'

export default function App() {
  return (
    <AppShell>
      <Route path="/" component={Landing} />
      <Route path="/landing" component={Landing} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/practice" component={Practice} />
      <Route path="/history" component={History} />
      <Route path="/referral" component={Referral} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/payment" component={Payment} />
      <Route path="/tips" component={Tips} />
      <Route path="/community" component={Community} />
      <Route path="/settings" component={Settings} />
      <Route path="/support" component={Support} />
      <Route path="/feedback" component={Feedback} />
    </AppShell>
  )
}