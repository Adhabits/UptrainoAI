Netlify deployment
- Build command: npm run build
- Publish directory: dist